export interface PortfolioPage {
  id: number;
  pageNumber: number;
  title: string;
  subtitle: string;
  category: 'profile' | 'ar_3d' | 'media' | 'posters' | 'editorial' | 'photo' | 'branding' | 'film';
  categoryLabel: string;
  image: string;
  thumbnail: string;
  description: string;
  highlights: string[];
  tools: string[];
  yearOrPeriod?: string;
  quote?: string;
}

export const CATEGORIES = [
  { id: 'all', label: 'Semua Halaman', count: 18 },
  { id: 'profile', label: 'Profil & Pengalaman', count: 4 },
  { id: 'ar_3d', label: 'AR & 3D Modelling', count: 2 },
  { id: 'media', label: 'Media Digital Kampus', count: 3 },
  { id: 'editorial', label: 'Cover E-Book PKM', count: 1 },
  { id: 'posters', label: 'Desain Poster', count: 1 },
  { id: 'photo', label: 'Fotografi & Kolor', count: 2 },
  { id: 'branding', label: 'Branding & Apparel', count: 3 },
  { id: 'film', label: 'Film & Sinematografi', count: 1 },
] as const;

export const PORTFOLIO_PAGES: PortfolioPage[] = [
  {
    id: 1,
    pageNumber: 1,
    title: 'Portofolio Cover',
    subtitle: 'Make with purpose · make some creations',
    category: 'profile',
    categoryLabel: 'Profil & Cover',
    image: '/pages/page_01.jpg',
    thumbnail: '/pages/thumb_01.jpg',
    description: 'Halaman sampul portofolio resmi Kasih Dua Monika dengan visual identity berani: kontras biru kobalt, aksen lime electric, dan karakter 3D dinamis.',
    highlights: [
      'Visual Identity & Direction: Bold Neo-Brutalist & Modern 3D',
      'Art Direction: Make with purpose, make some creations',
      'Koleksi karya kreatif terlengkap periode 2021 - 2026'
    ],
    tools: ['3D Modeling', 'Photoshop', 'Graphic Design'],
    quote: 'Make with purpose, make some creations.'
  },
  {
    id: 2,
    pageNumber: 2,
    title: 'Introduction — Who I Am',
    subtitle: 'Hello, I’m Monika',
    category: 'profile',
    categoryLabel: 'Profil & Bio',
    image: '/pages/page_02.jpg',
    thumbnail: '/pages/thumb_02.jpg',
    description: 'Profil pribadi, latar belakang pendidikan di bidang Sistem dan Teknologi Informasi, serta kontak resmi Kasih Dua Monika.',
    highlights: [
      'Mahasiswi Sistem & Teknologi Informasi — Universitas Muhammadiyah Pringsewu (2022 - 2026)',
      'Alumni SMK Negeri Sukoharjo (2019 - 2022)',
      'Spesialisasi: Desain Grafis, Analisis Data, dan Manajemen Multimedia',
      'Memiliki adaptabilitas tinggi, komunikasi tim solid, dan empati desain yang kuat'
    ],
    tools: ['Visual Design', 'Data Management', 'Multimedia Production'],
    yearOrPeriod: '2022 - 2026',
    quote: 'Graduate of the Information Systems and Technology program with a strong interest in technology, graphic design, and data analysis.'
  },
  {
    id: 3,
    pageNumber: 3,
    title: 'Skillset & Experience',
    subtitle: 'What I do best · Pengalaman Organisasi & Kerja',
    category: 'profile',
    categoryLabel: 'Skill & Karier',
    image: '/pages/page_03.jpg',
    thumbnail: '/pages/thumb_03.jpg',
    description: 'Daftar perangkat lunak kreatif yang dikuasai serta rekam jejak kepemimpinan media di kampus dan industri.',
    highlights: [
      'Website Administrator — Universitas Muhammadiyah Pringsewu (UMPRI CENTRE) [2026 - Now]',
      'Koordinator Divisi Media & Komunikasi — Himpunan Mahasiswa Sistem & Teknologi Informasi (HIMASTI) [2024 - 2025]',
      'Media Communication Team Member — Program Kreativitas Mahasiswa (PKM) [Aug 2023 - May 2024]',
      'Bendahara Umum — Ikatan Mahasiswa Muhammadiyah / Student Association [2023 - 2024]',
      'Internship Training Course — CV Ratu Mandiri [Feb - Apr 2021]'
    ],
    tools: ['Photoshop', 'Premiere Pro', 'Illustrator', 'After Effects', 'Lightroom', 'Unity', 'Canva', 'CapCut', 'Blender / Procreate'],
    yearOrPeriod: '2021 - 2026',
    quote: 'Graphic Design, Video/Photo Editing, 3D Modelling, Color Grading.'
  },
  {
    id: 4,
    pageNumber: 4,
    title: 'Vision and Mission',
    subtitle: 'How I make creations',
    category: 'profile',
    categoryLabel: 'Filosofi Desain',
    image: '/pages/page_04.jpg',
    thumbnail: '/pages/thumb_04.jpg',
    description: 'Prinsip panduan, visi jangka panjang, dan misi profesional Monika dalam memadukan seni dan teknologi interaktif.',
    highlights: [
      'Visi: Menjadi kreator yang mengintegrasikan seni dan teknologi secara mulus untuk menghasilkan desain fungsional, film, dan model 3D yang menginspirasi',
      'Visi: Menghasilkan karya multimedia berkualitas tinggi dan ekspresif untuk beragam audiens',
      'Misi: Eksplorasi berkelanjutan di bidang desain grafis, sinematografi, dan 3D modeling',
      'Misi: Meningkatkan standar visual setiap proyek dengan prinsip desain modern dan penguasaan tools terbaru'
    ],
    tools: ['Creative Direction', 'Design Philosophy', 'Visual Storytelling'],
    quote: 'Becoming a creator who seamlessly integrates art and technology to produce inspiring and functional designs, films, and 3D models.'
  },
  {
    id: 5,
    pageNumber: 5,
    title: 'Mobile Development — Budaya Nusantara AR',
    subtitle: 'Augmented Reality Mobile Project',
    category: 'ar_3d',
    categoryLabel: 'AR & 3D Modelling',
    image: '/pages/page_05.jpg',
    thumbnail: '/pages/thumb_05.jpg',
    description: 'Pengembangan aplikasi mobile berbasis Augmented Reality (AR) "Budaya Nusantara" yang menghadirkan rumah adat tradisional Lampung (Nuwo Sesat) dalam interaksi 3D nyata.',
    highlights: [
      'Fitur Interaktif: Camera AR untuk mendeteksi target dan menampilkan objek 3D secara real-time',
      'Modul Edukasi: Deskripsi mendalam sejarah Nuwo Sesat dan arsitektur panggung khas Lampung',
      'Antarmuka Pengguna (UI): Desain menu intuitif (Play, About, Exit) dengan transisi mulus',
      'Pengalaman Imersif: Memperkenalkan kebudayaan Nusantara melalui teknologi interaktif mobile'
    ],
    tools: ['Unity 3D', 'Vuforia / AR Core', 'UI/UX Mobile', 'C# Scripting'],
    quote: 'Here’s a quick peek into my mobile projects AR from neat interface details to interactive features.'
  },
  {
    id: 6,
    pageNumber: 6,
    title: 'Media Digital — Umpri Update & Press Releases',
    subtitle: 'Publikasi & Desain Komunikasi Kampus',
    category: 'media',
    categoryLabel: 'Media Digital Kampus',
    image: '/pages/page_06.jpg',
    thumbnail: '/pages/thumb_06.jpg',
    description: 'Seri desain poster digital dan materi siaran pers resmi untuk Universitas Muhammadiyah Pringsewu, merayakan prestasi nasional dan hari-hari besar.',
    highlights: [
      'Peringkat 2 Nasional Program Studi NERS UMPRI (Unggul Modern Islami)',
      'Poster Peringatan Hari Sumpah Pemuda: Narasi perjuangan pemuda era modern',
      'Visual Yudisium UMPRI IV TA 2025-2026',
      'Siaran Pelantikan Rektor Universitas Muhammadiyah Lamongan Masa Jabatan 2026-2030',
      'Sosialisasi & Konsolidasi Program Diktisaintek Berdampak'
    ],
    tools: ['Adobe Photoshop', 'Canva Pro', 'Typography Design', 'Social Media Layout'],
    quote: 'Sinergi dan Kesetaraan untuk Keunggulan Pendidikan — Transformasi Nasional, Daya Saing Global.'
  },
  {
    id: 7,
    pageNumber: 7,
    title: 'Media Digital — Instagram Feeds & Campaigns',
    subtitle: 'Konten Media Sosial & Engagement Organisasi',
    category: 'media',
    categoryLabel: 'Media Digital Kampus',
    image: '/pages/page_07.jpg',
    thumbnail: '/pages/thumb_07.jpg',
    description: 'Desain carousel dan feed Instagram interaktif untuk kegiatan kemahasiswaan HIMASTI dan BEM, termasuk peringatan hari nasional dan perekrutan anggota.',
    highlights: [
      'Postingan Hari Guru Nasional & Hari Anak Sedunia',
      'Feed Happy Father\'s Day & Dirgahayu Republik Indonesia',
      'Materi Perekrutan BEM & Pelantikan Kepengurusan HIMASTI',
      'Kampanye Minat & Bakat Mahasiswa Teknologi Informasi',
      'Optimasi tata letak feed Instagram untuk retensi dan keterbacaan tinggi'
    ],
    tools: ['Canva', 'Adobe Photoshop', 'Social Media Management', 'Instagram UI Mockup'],
    quote: 'Check this out: Engaging visual designs for student community building.'
  },
  {
    id: 8,
    pageNumber: 8,
    title: 'Project Showcase — Panduan Informasi Kampus',
    subtitle: 'Adobe Photoshop CS6 Visual Guides',
    category: 'media',
    categoryLabel: 'Media Digital Kampus',
    image: '/pages/page_08.jpg',
    thumbnail: '/pages/thumb_08.jpg',
    description: 'Poster panduan langkah-demi-langkah yang dirancang untuk membantu mahasiswa dan staf dalam prosedur operasional teknologi di kampus.',
    highlights: [
      'Panduan Alur Pengisian KRS Online via mahasiswa.umpri.ac.id',
      'Prosedur Pengoperasian: Langkah menyalakan dan mematikan komputer dengan benar di lab',
      'Infografis Pendaftaran Mahasiswa Baru UMPRI dengan instruksi terperinci',
      'Dirancang presisi menggunakan Adobe Photoshop CS6'
    ],
    tools: ['Adobe Photoshop CS6', 'Infographic Design', 'Information Architecture'],
    quote: 'One of my best works is a poster design I created for several informational media contents at my campus, which I designed using Adobe Photoshop CS6.'
  },
  {
    id: 9,
    pageNumber: 9,
    title: 'Cover E-Book Design — Riset Kolaborasi PKM',
    subtitle: 'Editorial as Emotion · Modul Pembelajaran Matematika',
    category: 'editorial',
    categoryLabel: 'Cover E-Book PKM',
    image: '/pages/page_09.jpg',
    thumbnail: '/pages/thumb_09.jpg',
    description: 'Koleksi desain cover e-book modul kurikulum Merdeka Belajar hasil kolaborasi riset Program Kreativitas Mahasiswa (PKM) bersama dosen pembimbing.',
    highlights: [
      'Matematika SMA Kelas XII: Bangun Ruang Sisi Datar Terintegrasi Rumah Adat Lampung',
      'Modul Kelas XI: Pemahaman Transformasi Geometri pada Seni Batik Lampung',
      'Matematika Umum Kelas XI Fase F: Modul Konsep Transformasi Fungsi',
      'E-LKPD: Lingkaran Berbasis Etnomatika SMA Kelas XI',
      'Memadukan nilai etnomatematika kearifan lokal Lampung dengan estetika modern'
    ],
    tools: ['Canva', 'Adobe Illustrator', 'Editorial Design', 'Cover Mockup'],
    quote: 'An E-Book cover I designed for a collaborative PKM research project with a lecturer, crafted using Canva, stands out as one of my most refined visual works.'
  },
  {
    id: 10,
    pageNumber: 10,
    title: 'Ideas Through Posters — Data & Event Posters',
    subtitle: 'Designing Data with Depth',
    category: 'posters',
    categoryLabel: 'Desain Poster',
    image: '/pages/page_10.jpg',
    thumbnail: '/pages/thumb_10.jpg',
    description: 'Eksplorasi poster beragam tema, mulai dari turnamen e-sport, malam keakraban organisasi mahasiswa, hingga poster ilmiah uji statistik mahasiswa.',
    highlights: [
      'Poster Turnamen Mobile Legends Bang Bang: Desain kompetitif bernuansa dynamic gold & gaming',
      'Poster SIKRAB HIMASTI (Silaturahmi dan Keakraban): Nuansa vintage typography & kebersamaan',
      'Poster Edukasi Lingkungan: "Selamatkan Bumi Kita"',
      'Poster Akademik Uji Statistik: Uji Normalitas Metode Lilliefors dan Uji Chi Kuadrat Dua Kelas'
    ],
    tools: ['Adobe Photoshop', 'Canva', 'Data Visualization', 'Event Branding'],
    quote: 'Several poster projects I have created, covering various themes ranging from math posters for student assignments to event posters for student organizations.'
  },
  {
    id: 11,
    pageNumber: 11,
    title: 'Captured Moments — A Journey in Frames',
    subtitle: 'What guides me · Passion in Photography',
    category: 'photo',
    categoryLabel: 'Fotografi & Kolor',
    image: '/pages/page_11.jpg',
    thumbnail: '/pages/thumb_11.jpg',
    description: 'Eksplorasi sudut pandang personal dan kecintaan Monika dalam menangkap momen kehidupan sehari-hari melalui lensa kamera.',
    highlights: [
      'Refleksi artistik perpaduan seni lukis klasik dan fotografi modern',
      'Ketajaman mengamati keindahan dalam kesederhanaan pasar tradisional dan jalanan',
      'Pondasi komposisi visual yang memperkuat rasa estetika di setiap desain digital'
    ],
    tools: ['DSLR / Mirrorless', 'Lightroom Mobile', 'Storytelling'],
    quote: 'I am also very passionate about photography wherever I go, I always make time to capture moments, even when I’m just walking through the market.'
  },
  {
    id: 12,
    pageNumber: 12,
    title: 'The Photo and Coloring Archive',
    subtitle: 'Open to creative photography collaboration',
    category: 'photo',
    categoryLabel: 'Fotografi & Kolor',
    image: '/pages/page_12.jpg',
    thumbnail: '/pages/thumb_12.jpg',
    description: 'Arsip kurasi fotografi jalanan, lanskap alam, arsitektur megah, still-life produk, dan teknik color grading profesional.',
    highlights: [
      'Lanskap pantai pesisir Lampung dengan pasir alami dan deburan ombak tenang',
      'Fotografi arsitektural Petronas Twin Towers dengan perspektif worm\'s-eye view',
      'Urban street photography: Suasana kota hujan, kereta api tempo dulu, dan pedagang pasar',
      'Still-life dan pencahayaan dramatis: Botol kopi Nescafe di antara dedaunan hijau alami',
      'Eksplorasi palet warna teal-orange, moody green, dan warm vintage'
    ],
    tools: ['Adobe Lightroom', 'Adobe Camera Raw', 'Photoshop Color Grading'],
    quote: 'The Photo and Coloring Archive — Open to creative photography collaboration.'
  },
  {
    id: 13,
    pageNumber: 13,
    title: '3D Modelling — Skincare Packaging Design',
    subtitle: 'Ideas, Shapes, and 3D Space',
    category: 'ar_3d',
    categoryLabel: 'AR & 3D Modelling',
    image: '/pages/page_13.jpg',
    thumbnail: '/pages/thumb_13.jpg',
    description: 'Pemodelan dan rendering 3D produk kosmetik kecantikan "LOVELIEY" & jar krim realistis yang telah dipublikasikan dan dijual secara online.',
    highlights: [
      'Model 3D jar krim skincare dengan detail label tipografi, ingredients, dan tutup akrilik',
      'Tekstur material kaca kosmetik transparan, dropper serum, dan aksen tutup emas metalik',
      'Pencahayaan studio fotorealistik dengan bayangan lembut dan pantulan permukaan glossy',
      'Karya model 3D komersial yang telah dipasarkan di platform marketplace online'
    ],
    tools: ['Blender 3D', 'Cycles / Eevee Renderer', 'Substance 3D', 'Photoshop'],
    quote: 'Here’s a look at my 3D modeling projects! Just a simple 3D project of a skincare jar. I focused on making it look realistic and neat. It\'s one of my works that I’ve published for sale online!'
  },
  {
    id: 14,
    pageNumber: 14,
    title: 'Brand Logo Design — Snack & Community Identity',
    subtitle: 'Branding & Beyond',
    category: 'branding',
    categoryLabel: 'Branding & Apparel',
    image: '/pages/page_14.jpg',
    thumbnail: '/pages/thumb_14.jpg',
    description: 'Pengembangan identitas visual logo produk kuliner kemasan pouch standing "PEDAAAS" & "CARAMEL" serta logo komunitas kreatif.',
    highlights: [
      'Desain stiker kemasan kraft standing pouch dengan grafis dinamis dan menggugah selera',
      'Eksplorasi varian rasa pedas membara dan karamel manis',
      'Desain maskot dan tipografi kustom untuk daya tarik ritel UMKM',
      'Diterapkan langsung pada produksi nyata produk makanan ringan'
    ],
    tools: ['Adobe Illustrator', 'CorelDraw', 'Product Mockup', 'Packaging Design'],
    quote: 'I’ve also worked on some brand logos, community logos, and t-shirt designs. Some were freelance gigs, and others were projects I did for my own communities.'
  },
  {
    id: 15,
    pageNumber: 15,
    title: 'Logos & Threads — Apparel & Uniform Merch',
    subtitle: 'Kemeja PDH Organisasi Kampus & Merchandise',
    category: 'branding',
    categoryLabel: 'Branding & Apparel',
    image: '/pages/page_15.jpg',
    thumbnail: '/pages/thumb_15.jpg',
    description: 'Perancangan busana pakaian dinas harian (PDH) organisasi mahasiswa SEMAURI UMPRI serta merchandise kasual (kaos, sweater, totebag, mug).',
    highlights: [
      'Kemeja PDH Resmi SEMAURI (Seni Mahasiswa UMPRI): Aksen tenun/batik khas Lampung pada pundak dengan warna tosca dan cokelat elegan',
      'Brand Merch "Lampungku": Kaos putih, sweater crewneck, tote bag pantai, dan mug keramik',
      'Spesifikasi teknis bordir komputer presisi untuk dada kiri, dada kanan, dan punggung'
    ],
    tools: ['Adobe Illustrator', 'Apparel Mockup', 'Fashion Graphic Design'],
    quote: 'Logos & Threads: Merancang identitas yang dapat dikenakan dengan kebanggaan.'
  },
  {
    id: 16,
    pageNumber: 16,
    title: 'From Campus to Corporate — Recent Logo Drops',
    subtitle: 'Identitas Visual Organisasi & Distributor Konstruksi',
    category: 'branding',
    categoryLabel: 'Branding & Apparel',
    image: '/pages/page_16.jpg',
    thumbnail: '/pages/thumb_16.jpg',
    description: 'Portofolio logo terkini mulai dari logo komunitas mahasiswa kampus hingga corporate logo perusahaan distribusi konstruksi profesional (LKM).',
    highlights: [
      'Corporate Identity LKM: Simbol pilar kokoh, modern, dan geometris untuk distributor konstruksi',
      'Community Logo HIMASTI & Robotika: Ikon gear dan monitor komputer dengan garis tegas',
      'Mockup stiker die-cut di laptop, kartu nama bisnis, dan stationary kantor',
      'Panduan proporsi grid dan pedoman penggunaan logo profesional'
    ],
    tools: ['Adobe Illustrator', 'Brand Guidelines', 'Stationery Mockup'],
    quote: 'Here are some of my recent logo designs from a campus community logo to one for a construction distribution company.'
  },
  {
    id: 17,
    pageNumber: 17,
    title: 'Behind the Lens — Short Film Stills',
    subtitle: 'Frames & Experiences · Sinematografi & Penyutradaraan',
    category: 'film',
    categoryLabel: 'Film & Sinematografi',
    image: '/pages/page_17.jpg',
    thumbnail: '/pages/thumb_17.jpg',
    description: 'Karya film pendek fiksi dan edukasi di mana Monika berperan aktif dalam sinematografi, penyutradaraan, dan pascaproduksi.',
    highlights: [
      'Film Pendek "Taubatnya Manusia Penjudi" (Karya Kelompok 1 HIMASTI)',
      'Film Edukasi Religi "Ikhtiar Aisyah" (SMK Negeri Sukoharjo)',
      'Film "Sadar Pajak" (Diproduksi oleh Tax Center Universitas Muhammadiyah Pringsewu, disutradarai bersama Kasih Dua Monika)',
      'Pengalaman menyeluruh: Storyboarding, direct cinematography, camera angles, color grading, dan audio synchronization'
    ],
    tools: ['Adobe Premiere Pro', 'After Effects', 'Cinematography', 'Sound Design'],
    yearOrPeriod: '2019 - 2025',
    quote: 'A few short films I’ve worked on. Even though they were small team efforts, they gave me so much new experience.'
  },
  {
    id: 18,
    pageNumber: 18,
    title: 'Let’s Connect! — Penutup & Kontak',
    subtitle: 'Kasih Dua Monika · Lampung, Indonesia',
    category: 'profile',
    categoryLabel: 'Kontak & Kolaborasi',
    image: '/pages/page_18.jpg',
    thumbnail: '/pages/thumb_18.jpg',
    description: 'Halaman penutup dengan seluruh saluran komunikasi resmi untuk kolaborasi desain grafis, 3D modelling, pembuatan video, maupun diskusi kreatif.',
    highlights: [
      'Email: kasihduamonika16@gmail.com',
      'WhatsApp / Telepon: +62 877 5037 1700 / 08876647009',
      'Instagram: @monikashii',
      'LinkedIn: Kasih Dua Monika',
      'Twitter / X: @KasihDua35296',
      'Domisili: Lampung, Indonesia'
    ],
    tools: ['WhatsApp', 'Email', 'LinkedIn', 'Instagram', 'Creative Networking'],
    quote: 'That’s a wrap! Thanks for sticking around. I’m always down for new projects or even just a quick chat about design. Let’s make something cool together!'
  }
];
