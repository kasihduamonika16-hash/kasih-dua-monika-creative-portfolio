import React from 'react';
import { ArrowUp, Sparkles, Heart } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-slate-900 bg-slate-950 py-10 text-slate-400 text-xs">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Left: Identity */}
        <div className="flex flex-col sm:flex-row items-center gap-3 text-center sm:text-left">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-lime-400 font-display font-black text-slate-950 text-xs">
            M
          </div>
          <div>
            <div className="font-semibold text-white">Kasih Dua Monika</div>
            <div className="text-[11px] text-slate-500">
              Sistem & Teknologi Informasi · Universitas Muhammadiyah Pringsewu
            </div>
          </div>
        </div>

        {/* Center: Offline & PWA notice */}
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-[11px] text-slate-400">
            <span className="h-2 w-2 rounded-full bg-lime-400 animate-pulse" />
            <span>PWA & Offline Ready</span>
          </span>
          <PWAInstallButton compact />
        </div>

        {/* Right: Back to top */}
        <div className="flex items-center gap-4">
          <span className="text-[11px] text-slate-500">
            © {new Date().getFullYear()} Kasih Dua Monika
          </span>
          <button
            onClick={scrollToTop}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-800 bg-slate-900 text-slate-300 hover:text-white hover:border-slate-700 transition"
            title="Kembali ke atas"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>
      </div>
    </footer>
  );
};
