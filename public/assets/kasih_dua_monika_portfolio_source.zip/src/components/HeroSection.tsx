import React from 'react';
import { ArrowDown, BookOpen, Download, Sparkles, Smartphone, CheckCircle2, MessageCircle } from 'lucide-react';

interface HeroSectionProps {
  onExploreClick: () => void;
  onOpenFlipbook: () => void;
  onOpenPage: (pageNumber: number) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExploreClick,
  onOpenFlipbook,
  onOpenPage,
}) => {
  return (
    <section className="relative overflow-hidden pt-6 pb-12 md:py-16">
      {/* Background ambient accents */}
      <div className="absolute top-0 left-1/4 h-96 w-96 -translate-x-1/2 rounded-full bg-blue-600/15 blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-10 h-80 w-80 rounded-full bg-lime-400/10 blur-3xl pointer-events-none" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* Main Hero Card Container with Monika's iconic visual style */}
        <div className="relative rounded-3xl border border-blue-900/60 bg-gradient-to-br from-blue-950 via-[#0e1438] to-slate-950 p-6 sm:p-10 lg:p-12 shadow-2xl overflow-hidden">
          {/* Decorative angled background ribbon */}
          <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-lime-400/10 blur-2xl pointer-events-none" />
          <div className="absolute right-0 bottom-0 w-96 h-96 bg-gradient-to-t from-blue-600/20 to-transparent pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left Content Column */}
            <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
              {/* Unboxed Metadata Kicker */}
              <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-slate-300">
                <span className="text-lime-400">Kasih Dua Monika</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span>Sistem & Teknologi Informasi UMPRI</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span>Portofolio Digital 2021–2026</span>
              </div>

              {/* Main Headline */}
              <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-[1.08] text-balance">
                Make with purpose, <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-lime-400 via-lime-300 to-emerald-400">
                  make some creations.
                </span>
              </h1>

              {/* Lead Paragraph */}
              <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
                Selamat datang di website portofolio interaktif <strong>Kasih Dua Monika</strong>. Diadaptasi langsung dari 18 halaman dokumen portofolio resmi: mulai dari pemodelan 3D kosmetik, aplikasi mobile Augmented Reality (AR) Nuwo Sesat, desain grafis kampus, modul e-book riset PKM, hingga arsip fotografi dan film pendek.
              </p>

              {/* Interactive Action Cluster */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={onExploreClick}
                  className="flex items-center gap-2.5 rounded-xl bg-lime-400 px-5 py-3 text-sm font-extrabold text-slate-950 shadow-lg shadow-lime-400/25 hover:bg-lime-300 active:scale-95 transition-all"
                >
                  <span>Lihat Semua 18 Halaman</span>
                  <ArrowDown className="w-4 h-4 stroke-[2.5]" />
                </button>

                <button
                  onClick={onOpenFlipbook}
                  className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900/90 hover:bg-slate-800 px-4 py-3 text-sm font-bold text-white shadow-sm hover:border-slate-500 active:scale-95 transition-all"
                >
                  <BookOpen className="w-4 h-4 text-blue-400" />
                  <span>Mode Presentasi / Flipbook</span>
                </button>

                <a
                  href="/assets/Portofolio_Monika_Web.pdf"
                  download="Portofolio_Kasih_Dua_Monika.pdf"
                  className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/60 hover:bg-slate-800/90 px-4 py-3 text-sm font-medium text-slate-300 hover:text-white transition-all"
                >
                  <Download className="w-4 h-4 text-slate-400" />
                  <span>Unduh File PDF (13 MB)</span>
                </a>
              </div>

              {/* Quick Feature Badges (Unboxed metadata style) */}
              <div className="pt-4 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-lime-400 shrink-0" />
                  <span>100% Interaktif & Klik Halaman</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-lime-400 shrink-0" />
                  <span>Dukungan Akses Offline PWA</span>
                </div>
                <div className="flex items-center gap-2 col-span-2 sm:col-span-1">
                  <CheckCircle2 className="w-4 h-4 text-lime-400 shrink-0" />
                  <span>Responsif Ponsel & Desktop</span>
                </div>
              </div>
            </div>

            {/* Right Visual Column: Interactive Showcase Cards */}
            <div className="lg:col-span-5 relative flex flex-col items-center">
              {/* Stacked Preview Card */}
              <div className="relative w-full max-w-md">
                {/* Background page teaser card */}
                <div 
                  onClick={() => onOpenPage(5)}
                  className="absolute -top-4 -right-3 w-11/12 rounded-2xl bg-blue-900/40 border border-blue-600/30 p-2 transform rotate-3 shadow-xl cursor-pointer hover:rotate-6 transition-transform"
                >
                  <img
                    src="/pages/thumb_05.jpg"
                    alt="Mobile AR Budaya Nusantara preview"
                    className="w-full aspect-[16/9] object-cover rounded-xl opacity-70"
                    loading="lazy"
                  />
                </div>

                {/* Main Front Hero Card (Cover Page 1) */}
                <div 
                  onClick={() => onOpenPage(1)}
                  className="relative z-10 group cursor-pointer overflow-hidden rounded-2xl border-2 border-lime-400/50 bg-slate-900 shadow-2xl transition-all duration-300 hover:-translate-y-1 hover:shadow-lime-400/20"
                >
                  <div className="relative aspect-[16/9] overflow-hidden bg-slate-950">
                    <img
                      src="/pages/page_01.jpg"
                      alt="Kasih Dua Monika Portfolio Cover"
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                    
                    {/* Hover Prompt Overlay */}
                    <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs font-semibold text-white">
                      <span className="flex items-center gap-1.5 text-lime-400">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Halaman 01 / 18</span>
                      </span>
                      <span className="rounded-lg bg-black/60 backdrop-blur-sm px-2.5 py-1 text-[11px] text-slate-200 group-hover:bg-lime-400 group-hover:text-slate-950 transition-colors">
                        Klik untuk Buka ↗
                      </span>
                    </div>
                  </div>
                </div>

                {/* Quick Shortcuts Bar under preview card */}
                <div className="mt-4 grid grid-cols-3 gap-2">
                  <button
                    onClick={() => onOpenPage(2)}
                    className="group rounded-xl border border-slate-800 bg-slate-900/80 p-2.5 text-left hover:border-slate-700 hover:bg-slate-800 transition"
                  >
                    <div className="text-[10px] font-bold text-lime-400">Hal. 02</div>
                    <div className="text-xs font-semibold text-slate-200 truncate group-hover:text-white">Bio & Profil</div>
                  </button>
                  <button
                    onClick={() => onOpenPage(5)}
                    className="group rounded-xl border border-slate-800 bg-slate-900/80 p-2.5 text-left hover:border-slate-700 hover:bg-slate-800 transition"
                  >
                    <div className="text-[10px] font-bold text-blue-400">Hal. 05</div>
                    <div className="text-xs font-semibold text-slate-200 truncate group-hover:text-white">Mobile AR</div>
                  </button>
                  <button
                    onClick={() => onOpenPage(13)}
                    className="group rounded-xl border border-slate-800 bg-slate-900/80 p-2.5 text-left hover:border-slate-700 hover:bg-slate-800 transition"
                  >
                    <div className="text-[10px] font-bold text-amber-400">Hal. 13</div>
                    <div className="text-xs font-semibold text-slate-200 truncate group-hover:text-white">3D Skincare</div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
