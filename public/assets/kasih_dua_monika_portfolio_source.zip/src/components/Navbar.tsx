import React, { useState } from 'react';
import { Menu, X, FileDown, Sparkles, Phone, BookOpen, Layers } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

interface NavbarProps {
  onOpenFlipbook: () => void;
  activeSection: string;
  onNavigate: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenFlipbook,
  activeSection,
  onNavigate,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isOnline = useOnlineStatus();

  const handleNavClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 md:gap-8">
        {/* Zone 1: Brand Wordmark */}
        <button
          onClick={() => handleNavClick('hero')}
          className="flex items-center gap-2.5 text-left group whitespace-nowrap shrink-0 focus:outline-none"
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-blue-700 via-indigo-600 to-lime-400 font-display font-black text-slate-950 text-base shadow-sm group-hover:scale-105 transition-transform">
            M
          </div>
          <div className="flex flex-col">
            <span className="font-display text-base font-extrabold tracking-tight text-white group-hover:text-lime-400 transition-colors">
              Kasih Dua Monika
            </span>
            <span className="text-[10px] font-medium text-slate-400">
              Creative Portfolio · Lampung
            </span>
          </div>
        </button>

        {/* Zone 2: Nav Links (Desktop) */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-300">
          <button
            onClick={() => handleNavClick('gallery')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-lime-400 ${
              activeSection === 'gallery' ? 'text-lime-400' : ''
            }`}
          >
            Semua Halaman (18)
          </button>
          <button
            onClick={() => handleNavClick('about')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-lime-400 ${
              activeSection === 'about' ? 'text-lime-400' : ''
            }`}
          >
            Profil & Skillset
          </button>
          <button
            onClick={() => handleNavClick('vision')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-lime-400 ${
              activeSection === 'vision' ? 'text-lime-400' : ''
            }`}
          >
            Visi & Misi
          </button>
          <button
            onClick={() => handleNavClick('contact')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-lime-400 ${
              activeSection === 'contact' ? 'text-lime-400' : ''
            }`}
          >
            Kontak
          </button>
        </nav>

        {/* Zone 3: Actions (Desktop & Mobile) */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Quick Reader Mode Button */}
          <button
            onClick={onOpenFlipbook}
            className="hidden lg:flex items-center gap-1.5 rounded-xl border border-blue-500/30 bg-blue-600/10 px-3 py-1.5 text-xs font-bold text-blue-400 hover:bg-blue-600/20 transition whitespace-nowrap"
            title="Buka Mode Flipbook Interaktif"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Mode Baca Interaktif</span>
          </button>

          {/* Download Original PDF */}
          <a
            href="/assets/Portofolio_Monika_Web.pdf"
            download="Portofolio_Kasih_Dua_Monika.pdf"
            className="flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:bg-slate-800 transition whitespace-nowrap"
            title="Download file PDF portofolio resmi (13 MB)"
          >
            <FileDown className="w-3.5 h-3.5 text-lime-400" />
            <span className="hidden sm:inline">Unduh PDF</span>
          </a>

          {/* PWA Install Button */}
          <PWAInstallButton compact />

          {/* Mobile hamburger menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle navigation menu"
            className="flex md:hidden h-9 w-9 items-center justify-center rounded-xl border border-slate-800 bg-slate-900 text-slate-300 hover:text-white"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-800/80 bg-slate-950 px-4 py-4 space-y-3">
          <div className="flex flex-col space-y-1">
            <button
              onClick={() => handleNavClick('gallery')}
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-left text-sm font-semibold text-slate-200 hover:bg-slate-900 hover:text-lime-400 transition"
            >
              <Layers className="w-4 h-4 text-lime-400" />
              <span>Daftar 18 Halaman Portofolio</span>
            </button>
            <button
              onClick={() => handleNavClick('about')}
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-left text-sm font-semibold text-slate-200 hover:bg-slate-900 hover:text-lime-400 transition"
            >
              <Sparkles className="w-4 h-4 text-blue-400" />
              <span>Profil, Bio & Pengalaman</span>
            </button>
            <button
              onClick={() => handleNavClick('vision')}
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-left text-sm font-semibold text-slate-200 hover:bg-slate-900 hover:text-lime-400 transition"
            >
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span>Visi, Misi & Filosofi</span>
            </button>
            <button
              onClick={() => handleNavClick('contact')}
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-left text-sm font-semibold text-slate-200 hover:bg-slate-900 hover:text-lime-400 transition"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Kontak & Sosial Media</span>
            </button>
          </div>

          <div className="pt-2 border-t border-slate-800/80 flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenFlipbook();
                setMobileMenuOpen(false);
              }}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-xs font-bold text-white shadow-md hover:bg-blue-500 transition"
            >
              <BookOpen className="w-4 h-4" />
              <span>Buka Flipbook Interaktif (Geser Halaman)</span>
            </button>
            <a
              href="https://wa.me/6287750371700?text=Halo%20Monika,%20saya%20tertarik%20dengan%20portofolio%20desain%20kamu!"
              target="_blank"
              rel="noopener noreferrer"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-lime-400 px-4 py-2 text-xs font-bold text-slate-950 shadow-md hover:bg-lime-300 transition"
            >
              <Phone className="w-4 h-4 stroke-[2.5]" />
              <span>Hubungi via WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
