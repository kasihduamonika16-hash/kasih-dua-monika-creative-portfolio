import React from 'react';
import { 
  GraduationCap, Briefcase, Award, ArrowRight, 
  ExternalLink, Code2, Palette, Video, Box 
} from 'lucide-react';

interface AboutSectionProps {
  onOpenPage: (pageNumber: number) => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ onOpenPage }) => {
  const experiences = [
    {
      role: 'Website Administrator',
      org: 'Universitas Muhammadiyah Pringsewu (UMPRI CENTRE)',
      period: '2026 – Sekarang',
      desc: 'Mengelola pemeliharaan website resmi, arsitektur informasi, serta integrasi media digital kampus.',
    },
    {
      role: 'Koordinator Divisi Media & Komunikasi',
      org: 'Himpunan Mahasiswa Sistem & Teknologi Informasi (HIMASTI)',
      period: '2024 – 2025',
      desc: 'Memimpin tim publikasi visual, desain feed Instagram, pembuatan video dokumentasi, dan poster kegiatan kemahasiswaan.',
    },
    {
      role: 'Media Communication Team Member',
      org: 'Program Kreativitas Mahasiswa (PKM)',
      period: 'Agu 2023 – Mei 2024',
      desc: 'Berkolaborasi dengan dosen dan tim riset dalam merancang cover e-book dan modul pembelajaran berbasis etnomatematika Lampung.',
    },
    {
      role: 'Bendahara Umum',
      org: 'Ikatan Mahasiswa Muhammadiyah (Student Association)',
      period: '2023 – 2024',
      desc: 'Mengelola administrasi keuangan dan pendanaan program kerja organisasi.',
    },
    {
      role: 'Internship Training Course',
      org: 'CV Ratu Mandiri',
      period: 'Feb – Apr 2021',
      desc: 'Pelatihan industri di bidang desain grafis, multimedia, dan produksi materi promosi.',
    },
  ];

  const softwareStack = [
    { name: 'Adobe Photoshop', category: 'Graphic & Photo', level: 'Advanced' },
    { name: 'Adobe Premiere Pro', category: 'Video Editing', level: 'Advanced' },
    { name: 'Adobe Illustrator', category: 'Vector & Logos', level: 'Proficient' },
    { name: 'Adobe After Effects', category: 'Motion & VFX', level: 'Proficient' },
    { name: 'Adobe Lightroom', category: 'Color Grading', level: 'Advanced' },
    { name: 'Unity 3D', category: 'Augmented Reality', level: 'Intermediate' },
    { name: 'Blender 3D', category: '3D Modelling', level: 'Intermediate' },
    { name: 'Canva Pro', category: 'Social Media & E-Book', level: 'Advanced' },
    { name: 'CapCut / Filmora', category: 'Short Video / Reels', level: 'Advanced' },
  ];

  return (
    <section id="about" className="py-12 md:py-16 bg-slate-950/60 border-t border-slate-800/80 scroll-mt-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-8 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-lime-400 mb-2">
              <Award className="w-3.5 h-3.5" />
              <span>Profil & Rekam Jejak</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Tentang Kasih Dua Monika
            </h2>
            <p className="mt-2 text-sm text-slate-400 max-w-2xl">
              Mahasiswi Program Studi Sistem dan Teknologi Informasi dengan passion kuat pada desain visual, pemodelan 3D, sinematografi, dan teknologi interaktif.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenPage(2)}
              className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:text-lime-400 hover:border-slate-700 transition"
            >
              <span>Buka Halaman Bio (Hal. 02)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onOpenPage(3)}
              className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:text-lime-400 hover:border-slate-700 transition"
            >
              <span>Buka Halaman Skill (Hal. 03)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 2-Column Content Split */}
        <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Photo Card & Education */}
          <div className="lg:col-span-5 space-y-6">
            <div className="relative overflow-hidden rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 to-slate-950 p-6 shadow-xl">
              <div className="flex flex-col sm:flex-row items-center gap-6">
                <div className="relative h-32 w-32 shrink-0 overflow-hidden rounded-2xl border-2 border-lime-400/50 shadow-lg">
                  <img
                    src="/assets/monika_photo.png"
                    alt="Kasih Dua Monika"
                    className="h-full w-full object-cover object-top"
                  />
                </div>
                <div className="space-y-1 text-center sm:text-left">
                  <h3 className="font-display text-xl font-bold text-white">
                    Kasih Dua Monika
                  </h3>
                  <p className="text-xs font-semibold text-lime-400">
                    Multimedia & Information Systems
                  </p>
                  <p className="text-xs text-slate-400 pt-1">
                    Lampung, Indonesia
                  </p>
                  <div className="pt-2 flex items-center justify-center sm:justify-start gap-2 text-xs text-slate-300">
                    <span className="font-mono text-lime-400 font-bold">0877-5037-1700</span>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-slate-800 text-xs text-slate-300 leading-relaxed">
                "Graduate of the Information Systems and Technology program with a strong interest in technology, graphic design, and data analysis. Experienced in multimedia, visual design, and data management. Possesses strong communication and teamwork skills, with the ability to adapt to new environments and learn new skills quickly."
              </div>
            </div>

            {/* Education Card */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 space-y-4">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-400">
                <GraduationCap className="w-4 h-4 text-blue-400" />
                <span>Pendidikan Formal</span>
              </div>

              <div className="space-y-4">
                <div className="border-l-2 border-blue-500/60 pl-3.5 space-y-0.5">
                  <h4 className="text-sm font-bold text-white">
                    Universitas Muhammadiyah Pringsewu
                  </h4>
                  <p className="text-xs text-lime-400 font-medium">
                    S1 Sistem & Teknologi Informasi
                  </p>
                  <p className="text-[11px] text-slate-400">
                    2022 – 2026 (Sekarang)
                  </p>
                </div>

                <div className="border-l-2 border-slate-700 pl-3.5 space-y-0.5">
                  <h4 className="text-sm font-bold text-white">
                    SMK Negeri Sukoharjo
                  </h4>
                  <p className="text-xs text-slate-300 font-medium">
                    Pendidikan Menengah Kejuruan
                  </p>
                  <p className="text-[11px] text-slate-400">
                    2019 – 2022
                  </p>
                </div>
              </div>
            </div>

            {/* Software Toolkit */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                  <Code2 className="w-4 h-4 text-lime-400" />
                  Software & Toolkit
                </span>
                <span className="text-[11px] text-lime-400 font-mono">9 Aplikasi Utama</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {softwareStack.map((tool, idx) => (
                  <div
                    key={idx}
                    className="rounded-xl border border-slate-800/80 bg-slate-950/60 p-2.5 text-xs"
                  >
                    <div className="font-semibold text-white truncate">{tool.name}</div>
                    <div className="text-[10px] text-slate-400 truncate">{tool.category}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Experience Timeline & Highlights */}
          <div className="lg:col-span-7 space-y-6">
            <div className="rounded-3xl border border-slate-800 bg-slate-900/40 p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-300">
                  <Briefcase className="w-4 h-4 text-lime-400" />
                  <span>Pengalaman Organisasi & Kerja</span>
                </div>
                <span className="text-xs text-slate-400">Periode 2021 – 2026</span>
              </div>

              <div className="space-y-6">
                {experiences.map((exp, idx) => (
                  <div key={idx} className="relative pl-6 border-l border-slate-800 space-y-1 group">
                    <span className="absolute -left-1.5 top-1.5 h-3 w-3 rounded-full border-2 border-slate-950 bg-lime-400 group-hover:scale-125 transition-transform" />
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                      <h4 className="text-sm font-bold text-white group-hover:text-lime-400 transition-colors">
                        {exp.role}
                      </h4>
                      <span className="font-mono text-[11px] font-semibold text-lime-400/90">
                        {exp.period}
                      </span>
                    </div>
                    <p className="text-xs font-medium text-blue-400">
                      {exp.org}
                    </p>
                    <p className="text-xs text-slate-300 leading-relaxed pt-1">
                      {exp.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Core Competencies Bento Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 space-y-2">
                <Palette className="w-5 h-5 text-lime-400" />
                <h4 className="text-sm font-bold text-white">Graphic & UI Design</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Desain feed Instagram, poster acara, modul kurikulum e-book, dan identitas visual komunitas.
                </p>
              </div>

              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 space-y-2">
                <Box className="w-5 h-5 text-blue-400" />
                <h4 className="text-sm font-bold text-white">3D & Augmented Reality</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Modeling produk skincare komersial di Blender dan aplikasi edukasi mobile AR Nuwo Sesat Lampung di Unity.
                </p>
              </div>

              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 space-y-2">
                <Video className="w-5 h-5 text-amber-400" />
                <h4 className="text-sm font-bold text-white">Film & Color Grading</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Sinematografi film pendek, editing video di Premiere Pro & After Effects, dan arsip fotografi jalanan.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
